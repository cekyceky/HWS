<?php $this->load->view('header'); ?>
<div class="data-table-area mg-b-15">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <!-- <div>
                                <a href="<?=base_url()?>index.php/user/tambah">
                                    <button class="btn btn- btn-xs" data-title="create" data-toogle="modal" data-target="#create">Add E-ktp</button>
                                </a>
                            </div><br> -->
                            <div class="sparkline13-list shadow-reset">
                                <div class="sparkline13-hd">
                                    <div class="main-sparkline13-hd">
                                        <h2> <span class="table-project-n">Data</span> Permintaan Blangko E-KTP</h1>
                                        <div class="sparkline13-outline-icon">
                                            <span class="sparkline13-collapse-link"><i class="fa fa-chevron-up"></i></span>
                                            <span><i class="fa fa-wrench"></i></span>
                                            <span class="sparkline13-collapse-close"><i class="fa fa-times"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="sparkline13-graph">
                                    <div class="datatable-dashv1-list custom-datatable-overright">
                                        <div id="toolbar">
                                            <div>
                                                <a href="<?=base_url()?>index.php/ektp/print">
                                                    <button class="btn btn- btn-xs" data-title="print" data-toogle="modal" data-target="#create">Cetak</button>
                                                </a>
                                            </div>
                                            <form class="form-inline" action="<?php echo base_url().'index.php/Ektp/tampil_admin_perbulan'; ?>" method="post">
                                                 <select class="form-control" name="bulan">
                                                    <option selected="selected" disabled="disabled" value="">Filter Bulan</option>
                                                    <option value="1">Januari</option>
                                                    <option value="2">Februari</option>
                                                    <option value="3">Maret</option>
                                                    <option value="4">April</option>
                                                    <option value="5">Mei</option>
                                                    <option value="6">Juni</option>
                                                    <option value="7">Juli</option>
                                                    <option value="8">Agustus</option>
                                                    <option value="9">September</option>
                                                    <option value="10">Oktober</option>
                                                    <option value="11">Nopember</option>
                                                    <option value="12">Desember</option>

                                                </select>
                                                <button class="btn btn- btn-xs" type="submit"> Filter </button>
                                            </form>
                                        </div>
                                        <table id="table" data-toggle="table" data-pagination="true" data-search="true" data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true" data-key-events="true" data-show-toggle="true" data-resizable="true" data-cookie="true" data-cookie-id-table="saveId" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                                            <thead>
                                                <tr>
                                                    <th data-field="state" data-checkbox="true"></th>
                                                    <th ><center>No.</center></th>
                                                    <th ><center>ID</center></th>
                                                    <th ><center>Bulan</center></th>
                                                    <th ><center>Tahun</center></th>
                                                    <th ><center>Permintaan</center></th>
                                                    <th ><center>Jumlah Tercetak</center></th>
                                                    <th ><center>Selisih</center></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $no = 1;foreach($blangko as $u){ ?>
                                                <tr>
                                                    <td></td>
                                                    <td><center><?php echo $no++ ?></center></td>
                                                    <td><center><?php echo $u->id ?></center></td>
                                                    <td><center><?php echo $u->nama_bulan ?></center></td>
                                                    <td><center><?php echo $u->nama_tahun ?></center></td>
                                                    <td><center><?php echo $u->terpakai ?></center></td>
                                                    <td><center><?php echo $u->jml_cetak ?></center></td>
                                                    <td><center><?php echo $u->hasilpengurangan ?></center></td>
                                                </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    
            <!-- <td colspan=3 height=10% bgcolor=black >
                    <br>
                    <hr align=center color=black size=3 width=90%>
                    <font size=2 color=black face="Times new roman" ><center> 
                        Copyright &copy 2018<b>&nbsp Proyek PKL</b></a><br>
                        Prodi Teknik Informatika | Jurusan Teknologi Informasi<br><b>POLITEKNIK NEGERI MALANG</b></a>
                        <br><br>
                    </center></font>
            </td>  -->     
<?php $this->load->view('footer'); ?>