<?php $this->load->view('header'); ?>
	<form class="form-horizontal" action="<?php echo base_url().'index.php/admin/tambah_user'; ?>" method="post" enctype="multipart/form-data">
		 <h2><center><span class="table-project-n">Tambah</span> Data User</center></h1>
		 	<br>
		 	<br>
		<div class="form-group">
    		<label class="col-lg-2 control-label">NIP</label>
    			<div class="col-lg-5">
    				<input type="text" name="nip">
    			</div>
		</div>
		<div class="form-group">
    		<label class="col-lg-2 control-label">Nama</label>
    			<div class="col-lg-5">
    				<input type="text" name="nama">
    			</div>
		</div>
		<div class="form-group">
    		<label class="col-lg-2 control-label">Username</label>
    			<div class="col-lg-5">
    				<input type="text" name="username">
    			</div>
		</div>
		<div class="form-group">
    		<label class="col-lg-2 control-label">Password</label>
    			<div class="col-lg-5">
    				<input type="text" name="password">
    			</div>
		</div>
		
		<div class="form-group">
    		<label class="col-lg-2 control-label">Hak Akses</label>
    			<div class="col-lg-5">
    				<input type="text" name="level">
    			</div>
		</div>
		<div class="form-group">
			<div class="col-lg-5">
				<label class="col-lg-2 control-label"></label>
				<tr>
		   			<input type="submit" value="Tambah" class="btn btn-primary" class="glyphicon glyphicon-plus">
				</tr>
			</div>
		</div>
		</table>
	</form>	
<?php $this->load->view('footer'); ?>