<?php 
$this->load->view('header_dashuser');
$this->load->model('Mdl_Alternatif');
$this->load->model('Mdl_NilaiAwal');

$altObj = new Alternatif($db);
$count = $altObj->countAll();

$nilObj = new NilaiAwal($db);?>
<div class="data-table-area mg-b-15">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="sparkline13-list shadow-reset">
                                <div class="sparkline13-hd">
                                    <div class="main-sparkline13-hd">
                                        <h2> <span class="table-project-n">Data</span> Tahun</h1>
                                        <div class="sparkline13-outline-icon">
                                            <span class="sparkline13-collapse-link"><i class="fa fa-chevron-up"></i></span>
                                            <span><i class="fa fa-wrench"></i></span>
                                            <span class="sparkline13-collapse-close"><i class="fa fa-times"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="sparkline13-graph">
                                    <div class="datatable-dashv1-list custom-datatable-overright">
                                            <a href="<?=base_url()?>index.php/tahun/tambah">
                                                <button class="btn btn- btn-xs" data-title="create" data-toogle="modal" data-target="#create">Tambah Data Tahun</button>
                                            </a>
                                        
                                        <table id="table" data-toggle="table" data-pagination="true" data-search="true" data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true" data-key-events="true" data-show-toggle="true" data-resizable="true" data-cookie="true" data-cookie-id-table="saveId" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                                            <thead>
                                                <tr>
                                                    <th width="10px"><input type="checkbox" name="select-all" id="select-all" /></th>
                                                    <th>ID Alternatif</th>
                                                    <th>Nik</th>
                                                    <th>Nama</th>
                                                    <th>Tempat, Tanggal Lahir</th>
                                                    <th>Kelamin</th>
                                                    <th>Jabatan</th>
                                                    <th>Tanggal Masuk</th>
                                                    <th>Pendidikan</th>
                                                    <th>Nilai</th>
                                                    <th width="100px">Aksi</th>
                                            </thead>
                                            <tbody>
                                                <?php $no = 1;foreach($data_alternatif as $alter){ ?>
                                                <tr>
                                                    <td></td>
                                                    <td><input type="checkbox" value="<?php echo $alter->id_alternatif ?>" name="checkbox[]" /></td>
                                                    <td><center><?php echo $alter->id_alternatif ?></center></td>
                                                    <td><center><?php echo $alter->nik ?></center></td>
                                                    <td><center><?php echo $alter->nama ?></center></td>
                                                    <td><center><?php echo $alter->tempat_lahir ?>,
                                                        <?php echo $alter->tanggal_lahir ?></center></td>
                                                    <td><center><?php echo $alter->kelamin ?></center></td>
                                                    <td><center><?php echo $alter->jabatan ?></center></td>
                                                    <td><center><?php echo $alter->tanggal_masuk ?></center></td>
                                                    <td><center><?php echo $alter->pendidikan ?></center></td>
                                                    <td>
                                                        <?php $nilObj->id_alternatif = $row['id_alternatif']; $nilObj->readByAlternatif(); if ($nilObj->id): ?>
                                                        <?=$nilObj->nilai?> (<?=$nilObj->keterangan?>)
                                                        <?php else: ?>
                                                            <span class="label label-danger">Belum</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="text-center">
                                                        <a href="data-alternatif-ubah.php?id=<?=$row['id_alternatif']?>" class="btn btn-warning btn-xs"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></a>
                                                        <a href="data-alternatif-hapus.php?id=<?=$row['id_alternatif']?>" onclick="return confirm('Yakin ingin menghapus data')" class="btn btn-danger btn-xs"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>
                                                    </td>
                                                </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>   
<?php $this->load->view('footer'); ?>