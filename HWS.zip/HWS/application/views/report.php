<script type="text/javascript">
        window.onload = function(){ window.print();}
    </script>
<table align="center" border=0>
    <tr align="center">
        <td><img src="<?php echo base_url();?>assets/img/logo kota madiun.png" height='10%'></td>
        <td colspan="2">Pemerintah Kota Madiun
            <br>
            Dinas Kependudukan Dan Pencatatan Sipil Kota Madiun
        </td>
        <td><img src="<?php echo base_url();?>assets/img/karismatik.png" height='30%'></td>
    </tr>
    <tr>
        <td colspan="4"><br></td>
    </tr>
    <tr>
        <td colspan="4"><center><b>Data Selilih Permintaan dan Ketersediaan</b></center><br></td>
    </tr>
    <tr>
        <td colspan="4"><br></td>
    </tr>
    <tr>
        <th ><center>No.</center></th>
        <th ><center>Bulan</center></th>
        <th ><center>Tahun</center></th>
        <th ><center>Selisih</center></th>
    </tr>
            <?php $no = 1;foreach($blangko as $u){ ?>
            <tr>
                <td><center><?php echo $no++ ?></center></td>
                <td><?php echo $u->nama_bulan ?></td>
                <td><center><?php echo $u->nama_tahun ?></center></td>
                <td><center><?php echo $u->hasilpengurangan ?></center></td>
            </tr>
            <?php } ?>
</table>