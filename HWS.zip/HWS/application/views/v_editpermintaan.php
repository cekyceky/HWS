<?php $this->load->view('header_user'); ?>
<body>
	<center>
		<h3>Edit Data</h3>
	</center>
	<?php foreach($permintaan as $u){ ?>
	<form class="form-horizontal" action="<?php echo base_url().'index.php/permintaan/update'; ?>" method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label class="col-lg-2 control-label">ID</label>
            <div class="col-lg-5">
                <input type="" name="id_permintaan" value="<?php echo $u->id_permintaan ?>">
            </div>
    </div>
    <div class="form-group">
        <label class="col-lg-2 control-label">Bulan</label>
        	<div class="col-lg-5">
                    <select class="form-control" name="id_bulan" id="id_bulan">
                            <?php foreach($groups as $row)
                                { 
                                  echo '<option value="'.$row->id_bulan.'">'.$row->nama_bulan.'</option>';
                                }
                                ?>
                    </select>
			</div>
    </div> 
    <div class="form-group">
        <label class="col-lg-2 control-label">Tahun</label>
        	<div class="col-lg-5">
                <select class="form-control" name="id_tahun" id="id_tahun">
                            <?php foreach($groups1 as $row)
                                { 
                                  echo '<option value="'.$row->id_tahun.'">'.$row->nama_tahun.'</option>';
                                }
                                ?>
                    </select>
        	</div>
    </div>
    <div class="form-group">
        <label class="col-lg-2 control-label">Permintaan</label>
            <div class="col-lg-5">
                <input type="text" name="jml_permintaan" value="<?php echo $u->jml_permintaan ?>">
            </div>
    </div>
    <div class="form-group">
    	<label class="col-lg-2 control-label"></label>
    		<div class="col-lg-5">
        		<button class="btn btn-primary"><i class="glyphicon glyphicon-hdd"></i> Update</button>
       			<a href="<?php echo site_url('permintaan');?>" class="btn btn-default">Kembali</a>
       		</div>
    </div>
       			
     	
	<?php } ?>
	


	 		<script src="<?php echo base_url('assets/js/holder.js');?>"></script>
    
            <script src="<?php echo base_url('assets/js/application.js');?>"></script>
            <script src="<?php echo base_url('assets/js/jquery-1.10.2.js');?>"></script>
            <script src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script>
            <script src="<?php echo base_url('assets/js/plugins/metisMenu/jquery.metisMenu.js');?>"></script>
            <script src="<?php echo base_url('assets/js/plugins/morris/raphael-2.1.0.min.js');?>"></script>
            <script src="<?php echo base_url('assets/js/plugins/morris/morris.js');?>"></script>
            <script src="<?php echo base_url('assets/js/sb-admin.js');?>"></script>
            <script src="<?php echo base_url('assets/js/demo/dashboard-demo.js');?>"></script>   
	</body>
    <?php $this->load->view('footer'); ?>
</html>