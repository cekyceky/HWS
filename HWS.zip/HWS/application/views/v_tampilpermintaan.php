<?php $this->load->view('header_user'); ?>
<div class="data-table-area mg-b-15">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div>
                                <a href="<?=base_url()?>index.php/permintaan/tambah">
                                    <button class="btn btn- btn-xs" data-title="create" data-toogle="modal" data-target="#create">Add Permintaan E-ktp</button>
                                </a>
                            </div><br>
                            <div class="sparkline13-list shadow-reset">
                                <div class="sparkline13-hd">
                                    <div class="main-sparkline13-hd">
                                        <h2> <span class="table-project-n">Data</span> Permintaan Blangko E-KTP</h1>
                                        <div class="sparkline13-outline-icon">
                                            <span class="sparkline13-collapse-link"><i class="fa fa-chevron-up"></i></span>
                                            <span><i class="fa fa-wrench"></i></span>
                                            <span class="sparkline13-collapse-close"><i class="fa fa-times"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="sparkline13-graph">
                                    <div class="datatable-dashv1-list custom-datatable-overright">
                                        <div id="toolbar">
                                            <select class="form-control">
                                                <option value="">Export Basic</option>
                                                <option value="all">Export All</option>
                                                <option value="selected">Export Selected</option>
                                            </select>
                                        </div>
                                        <table id="table" data-toggle="table" data-pagination="true" data-search="true" data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true" data-key-events="true" data-show-toggle="true" data-resizable="true" data-cookie="true" data-cookie-id-table="saveId" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                                            <thead>
                                                <tr>
                                                    <th data-field="state" data-checkbox="true"></th>
                                                    <th ><center>No.</center></th>
                                                    <th ><center>ID</center></th>
                                                    <th ><center>Bulan</center></th>
                                                    <th ><center>Tahun</center></th>
                                                    <th ><center>Jumlah Permintaan</center></th>
                                                    <th ><center>Action</center></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $no = 1;foreach($permintaan as $u){ ?>
                                                <tr>
                                                    <td></td>
                                                    <td><center><?php echo $no++ ?></center></td>
                                                    <td><center><?php echo $u->id_permintaan ?></center></td>
                                                    <td><center><?php echo $u->nama_bulan ?></center></td>
                                                    <td><center><?php echo $u->nama_tahun ?></center></td>
                                                    <td><center><?php echo $u->jml_permintaan ?></center></td>
                                                    <td><center><a href="<?php echo site_url('permintaan/edit/'.$u->id_permintaan);?>"><i class="glyphicon glyphicon-edit"></i></a>
                                                    &nbsp &nbsp &nbsp
                                                    <button class="btn btn- btn-xs" href="#" data-toggle="modal" data-target="#DangerModalftblack<?php echo $u->id_permintaan;?>"><i class="glyphicon glyphicon-trash"></i></button>
                            
                                                            <div id="DangerModalftblack<?php echo $u->id_permintaan;?>" class="modal modal-adminpro-general FullColor-popup-DangerModal PrimaryModal-bgcolor fade" role="dialog">
                                                                <div class="modal-dialog">
                                                                    <div class="modal-content">
                                                                        <div class="modal-close-area modal-close-df">
                                                                            <a class="close" data-dismiss="modal" href="#"><i class="fa fa-close"></i></a>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            <span class="adminpro-icon adminpro-danger-error modal-check-pro information-icon-pro"></span>
                                                                            <h2>Attention!</h2>
                                                                            <p>Apakah anda yakin ingin menghapus data ini ?</p>
                                                                        </div>
                                                                        <div class="modal-footer footer-modal-admin">
                                                                            <center><a style="color: yellow" data-dismiss="modal" href="">Tidak</a>
                                                                            <a style="color: yellow" href="<?php echo site_url('permintaan/hapus/'.$u->id_permintaan);?>">Iya Yakin</a></center>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                    <!-- <a href="<?php echo site_url('cruduser/hapus/'.$u->id_user);?>"><i class="glyphicon glyphicon-trash"></i></a></center></td> -->
                                                </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    
            <!-- <td colspan=3 height=10% bgcolor=black >
                    <br>
                    <hr align=center color=black size=3 width=90%>
                    <font size=2 color=black face="Times new roman" ><center> 
                        Copyright &copy 2018<b>&nbsp Proyek PKL</b></a><br>
                        Prodi Teknik Informatika | Jurusan Teknologi Informasi<br><b>POLITEKNIK NEGERI MALANG</b></a>
                        <br><br>
                    </center></font>
            </td>  -->     
<?php $this->load->view('footer'); ?>