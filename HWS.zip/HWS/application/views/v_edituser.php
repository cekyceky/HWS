<?php $this->load->view('header'); ?>
<body>
	<center>
		<h3>Edit Data</h3>
	</center>
	<?php foreach($users as $u){ ?>
	<form class="form-horizontal" action="<?php echo base_url().'index.php/admin/update'; ?>" method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label class="col-lg-2 control-label">NIP</label>
            <div class="col-lg-5">
                <!-- <fieldset disabled="disabled"> -->
                    <input type="" name="nip" value="<?php echo $u->nip ?>">
                <!-- </fieldset> -->
            </div>
    </div>
    <div class="form-group">
        <label class="col-lg-2 control-label">Username</label>
        	<div class="col-lg-5">
					<input type="" name="username" value="<?php echo $u->username ?>">
					<input type="hidden" name="password" value="<?php echo $u->password ?>">
			</div>
    </div> 
    <div class="form-group">
        <label class="col-lg-2 control-label">Hak Akses</label>
        	<div class="col-lg-5">
        		<input type="text" name="level" value="<?php echo $u->level ?>">
        	</div>
    </div>
    <div class="form-group">
    	<label class="col-lg-2 control-label"></label>
    		<div class="col-lg-5">
        		<button class="btn btn-primary"><i class="glyphicon glyphicon-hdd"></i> Update</button>
       			<a href="<?php echo site_url('admin');?>" class="btn btn-default">Kembali</a>
       		</div>
    </div>
       			
     	
	<?php } ?>
	


	 		<script src="<?php echo base_url('assets/js/holder.js');?>"></script>
    
            <script src="<?php echo base_url('assets/js/application.js');?>"></script>
            <script src="<?php echo base_url('assets/js/jquery-1.10.2.js');?>"></script>
            <script src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script>
            <script src="<?php echo base_url('assets/js/plugins/metisMenu/jquery.metisMenu.js');?>"></script>
            <script src="<?php echo base_url('assets/js/plugins/morris/raphael-2.1.0.min.js');?>"></script>
            <script src="<?php echo base_url('assets/js/plugins/morris/morris.js');?>"></script>
            <script src="<?php echo base_url('assets/js/sb-admin.js');?>"></script>
            <script src="<?php echo base_url('assets/js/demo/dashboard-demo.js');?>"></script>   
	</body>
    <?php $this->load->view('footer'); ?>
</html>