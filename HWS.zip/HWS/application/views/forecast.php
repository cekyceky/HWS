<?php $this->load->view('header_user'); ?>
	<form class="form-horizontal" action="<?php echo base_url().'index.php/forecast/getBulan'; ?>" method="post" enctype="multipart/form-data">
		<div class="form-group">
    		<label class="col-lg-2 control-label">Bulan</label>
    			<div class="col-lg-2">
    				 <select class="form-control" name="bulan">
                        <option selected="selected" disabled="disabled" value="">Pilih Bulan</option>
                        <option value="1">Januari</option>
                        <option value="2">Februari</option>
                        <option value="3">Maret</option>
                        <option value="4">April</option>
                        <option value="5">Mei</option>
                        <option value="6">Juni</option>
                        <option value="7">Juli</option>
                        <option value="8">Agustus</option>
                        <option value="9">September</option>
                        <option value="10">Oktober</option>
                        <option value="11">November</option>
                        <option value="12">Desember</option>
                     </select>
    			</div>
            </div>

        <div class="form-group">
            <label class="col-lg-2 control-label">Tahun</label>    
		        <div class="col-lg-2">
                     <select class="form-control" name="tahun">
                        <option selected="selected" disabled="disabled" value="">Pilih Tahun</option>
                        <?php 
                            for ($x = 1; $x <= 5; $x++) {
                                $nilai = $getTahunAkhir[0]->tahun+$x;
                                echo "<option value='".$nilai."'>".$nilai."</option>";
                            } 
                        ?>
                     </select>
                </div>
        </div> 
		<!-- <div class="form-group">
    		<label class="col-lg-2 control-label">Alfa</label>
    			<div class="col-lg-5">
    				<input type="text" name="alfa">
    			</div>
		</div> -->
		<div class="form-group">
			<div class="col-lg-5">
				<label class="col-lg-2 control-label"></label>
				<tr>
		   			<input type="submit" value="Forecast" class="btn btn-primary" class="glyphicon glyphicon-plus">
				</tr>
			</div>
		</div>
		</table>
	</form>	
<?php $this->load->view('footer'); ?>