<?php $this->load->view('header_dashboard'); ?>
<div class="data-table-area mg-b-15">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="sparkline13-list shadow-reset">
                                <div class="sparkline13-hd">
                                    <div class="main-sparkline13-hd">
                                        <!-- <h2> <span class="table-project-n">Data</span> Users</h1> -->
                                        <div class="sparkline13-outline-icon">
                                            <span class="sparkline13-collapse-link"><i class="fa fa-chevron-up"></i></span>
                                            <span><i class="fa fa-wrench"></i></span>
                                            <span class="sparkline13-collapse-close"><i class="fa fa-times"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="sparkline13-graph">
                                   <!-- <div id="container2" style="min-width: 100%; height: 400px; margin: 0 auto"></div> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <!-- <td colspan=3 height=10% bgcolor=black >
                    <br>
                    <hr align=center color=black size=3 width=90%>
                    <font size=2 color=black face="Times new roman" ><center> 
                        Copyright &copy 2018<b>&nbsp Proyek PKL</b></a><br>
                        Prodi Teknik Informatika | Jurusan Teknologi Informasi<br><b>POLITEKNIK NEGERI MALANG</b></a>
                        <br><br>
                    </center></font>
            </td>  -->     
<?php $this->load->view('footer'); ?>