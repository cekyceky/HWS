<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Sistem Peramalan</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- favicon
    ============================================ -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url();?>assets/img/KotaMadiun.ico">
    <!-- Google Fonts
    ============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i,800" rel="stylesheet">
    <!-- Bootstrap CSS
    ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
    <!-- Bootstrap CSS
    ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/font-awesome.min.css">
    <!-- adminpro icon CSS
    ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/adminpro-custon-icon.css">
    <!-- meanmenu icon CSS
    ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/meanmenu.min.css">
    <!-- mCustomScrollbar CSS
    ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery.mCustomScrollbar.min.css">
    <!-- animate CSS
    ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/animate.css">
    <!-- data-table CSS
    ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/data-table/bootstrap-table.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/data-table/bootstrap-editable.css">
    <!-- normalize CSS
    ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/normalize.css">
    <!-- charts C3 CSS
    ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/c3.min.css">
    <!-- forms CSS
    ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/form/all-type-forms.css">
    <!-- modals CSS
    ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/modals.css">
    <!-- notifications CSS
        ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/Lobibox.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/notifications.css">
    <!-- tabs CSS
    ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/tabs.css">
    <!-- style CSS
    ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/style.css">
    <!-- responsive CSS
    ============================================ -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/responsive.css">
    <!-- modernizr JS
    ============================================ -->
    <script src="<?php echo base_url();?>assets/js/vendor/modernizr-2.8.3.min.js"></script>
	
	<script type="text/javascript">
		window.onload = function(){ window.print();}
	</script>
	<title>Print</title>
            <div class="sparkline13-graph">
                <div class="datatable-dashv1-list custom-datatable-overright">
                        <br>
                        <img src="<?php echo base_url();?>assets/img/logo kota madiun.png" height='20%' width='20%'>
                        <br>
                        <br>
                    <font size=4 color=black face="Times new roman" ><center> 
                        Dinas Kependudukan dan Pencatatan Sipil<br>
                        Kota Madiun</a>
                        <br>
                        <br>
                        </center>
                    </font>
                </div>
            </div>
</head>
<body>
	<table id="table" data-toggle="table" data-pagination="true" data-search="false" data-show-columns="false" data-show-pagination-switch="false" data-show-refresh="false" data-key-events="false" data-show-toggle="false" data-resizable="true" data-cookie="true" data-cookie-id-table="saveId" data-show-export="false" data-click-to-select="true" data-toolbar="#toolbar">
        <thead>
            <tr>
                <th ><center>No.</center></th>
                <th ><center>ID</center></th>
                <th ><center>Bulan</center></th>
                <th ><center>Tahun</center></th>
                <th ><center>Hasil Peramalan</center></th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1;foreach($forecasting as $u){ ?>
            <tr>
                <td><center><?php echo $no++ ?></center></td>
                <td><center><?php echo $u->id_forecast ?></center></td>
                <td><center><?php echo $u->bulan ?></center></td>
                <td><center><?php echo $u->tahun ?></center></td>
                <td><center><?php echo $u->hasil ?></center></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
    <script src="<?php echo base_url();?>assets/js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
    ============================================ -->
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <!-- meanmenu JS
    ============================================ -->
    <script src="<?php echo base_url();?>assets/js/jquery.meanmenu.js"></script>
    <!-- mCustomScrollbar JS
    ============================================ -->
    <script src="<?php echo base_url();?>assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- sticky JS
    ============================================ -->
    <script src="<?php echo base_url();?>assets/js/jquery.sticky.js"></script>
    <!-- scrollUp JS
    ============================================ -->
    <script src="<?php echo base_url();?>assets/js/jquery.scrollUp.min.js"></script>
    <!-- modal JS
        ============================================ -->
    <script src="<?php echo base_url();?>assets/js/modal-active.js"></script>
    <!-- notification JS
        ============================================ -->
    <script src="<?php echo base_url();?>assets/js/Lobibox.js"></script>
    <script src="<?php echo base_url();?>assets/js/notification-active.js"></script>
    <!-- counterup JS
    ============================================ -->
    <script src="<?php echo base_url();?>assets/js/counterup/jquery.counterup.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/counterup/waypoints.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/counterup/counterup-active.js"></script>
    <!-- peity JS
    ============================================ -->
    <script src="<?php echo base_url();?>assets/js/peity/jquery.peity.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/peity/peity-active.js"></script>
    <!-- sparkline JS
    ============================================ -->
    <script src="<?php echo base_url();?>assets/js/sparkline/jquery.sparkline.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/sparkline/sparkline-active.js"></script>
    <!-- flot JS
    ============================================ -->
    <script src="<?php echo base_url();?>assets/js/flot/Chart.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/flot/flot-active.js"></script>
    <!-- map JS
    ============================================ -->
    <script src="<?php echo base_url();?>assets/js/map/raphael.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/map/jquery.mapael.js"></script>
    <script src="<?php echo base_url();?>assets/js/map/france_departments.js"></script>
    <script src="<?php echo base_url();?>assets/js/map/world_countries.js"></script>
    <script src="<?php echo base_url();?>assets/js/map/usa_states.js"></script>
    <script src="<?php echo base_url();?>assets/js/map/map-active.js"></script>
    <!-- data table JS
    ============================================ -->
    <script src="<?php echo base_url();?>assets/js/data-table/bootstrap-table.js"></script>
    <script src="<?php echo base_url();?>assets/js/data-table/tableExport.js"></script>
    <script src="<?php echo base_url();?>assets/js/data-table/data-table-active.js"></script>
    <script src="<?php echo base_url();?>assets/js/data-table/bootstrap-table-editable.js"></script>
    <script src="<?php echo base_url();?>assets/js/data-table/bootstrap-editable.js"></script>
    <script src="<?php echo base_url();?>assets/js/data-table/bootstrap-table-resizable.js"></script>
    <script src="<?php echo base_url();?>assets/js/data-table/colResizable-1.5.source.js"></script>
    <script src="<?php echo base_url();?>assets/js/data-table/bootstrap-table-export.js"></script>
    <!-- main JS
    ============================================ -->
    <script src="<?php echo base_url();?>assets/js/main.js"></script>
</body>
</html>