<?php $this->load->view('header_user') ?>
<?php
 $dataPoints1 = []; //data asli

  foreach ($grafik as $key) {
    $data_charthasilperamalan2 = array(
                "hasilperamalan" => $key['St'],
                "label" => $key['nama_tahun'],
                "y" => $key['St']
        );
      
  array_push($dataPoints1, $data_charthasilperamalan2);
  }

 $dataPoints2 = []; //data hasil peramalan

  foreach ($grafik as $key) {
    $data_charthasilperamalan1 = array(
                "hasilperamalan" => $key['ft+m'],
                "label" => $key['nama_tahun'],
                "y" => $key['ft+m']
        );
      
  array_push($dataPoints2, $data_charthasilperamalan1);
  }
  

?>

<script>
window.onload = function () {
 
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	exportEnabled: true,
	theme: "light2",
	title:{
		text: "Grafik Peramalan Data Permintaan dan Hasil Peramalan"
	},
	axisX:{
		crosshair: {
			enabled: true,
			snapToDataPoint: true
		}
	},
	axisY:{
		title: "Jumlah",
		crosshair: {
			enabled: true,
			snapToDataPoint: true
		}
	},
	toolTip:{
		enabled: false
	},
	data: [{
		type: "area",
		name: ": Data Permintaan :",
		showInLegend: "true",
		dataPoints: <?php echo json_encode($dataPoints1,JSON_NUMERIC_CHECK); ?>
	},
	{
		type: "area",
		name: ": Data Peramalan",
		showInLegend: "true",
		dataPoints: <?php echo json_encode($dataPoints2,JSON_NUMERIC_CHECK); ?>
	}
	]
});
chart.render();
 
}
</script>



	 <div class="sparkline13-graph">
	 	<div class="table-responsive">
	 		<h1>Peramalan Bulan 
	 			<?php
	 			if($nama_bulan == 1)
	 			{
	 				echo "Januari";
	 			}
	 			elseif($nama_bulan == 2)
	 			{
	 				echo "Februari";
	 			}
	 			elseif($nama_bulan == 3) 
	 			{
	 				echo "Maret";
	 			}
	 			elseif($nama_bulan == 4)
	 			{
	 				echo "April";
	 			}
	 			elseif($nama_bulan == 5) 
	 			{
	 				echo "Mei";
	 			}
	 			elseif($nama_bulan == 6)
	 			{
	 				echo "Juni";
	 			}
	 			elseif($nama_bulan == 7)
	 			{
	 				echo "Juli";
	 			}
	 			elseif($nama_bulan == 8)
	 			{
	 				echo "Agustus";
	 			}
	 			elseif($nama_bulan == 9)
	 			{
	 				echo "September";
	 			}
	 			elseif($nama_bulan == 10)
	 			{
	 				echo "Oktober";
	 			}elseif($nama_bulan == 11)
	 			{
	 				echo "November";
	 			}else{
	 				echo "Desember";
	 			}
	 			 ?></h1>
	 		<br>
	 		</div>
   <table class="table table-striped table-bordered">
	    <tr>
	     <th><center>Tahun</center></th>
	     <th><center>Data Permintaan</center></th>
	     <th><center>Pemulusan 1</center></th>
	     <th><center>Pemulusan 2</center></th>
	     <th><center>Konstanta a</center></th>
	     <th><center>Konstanta b</center></th>
	     <th><center>Hasil Peramalan</center></th>
	     <th><center>Nilai Error</center></th>
	     <th><center>Data Real</center></th>
	    </tr>
	    <?php foreach ($order as $order_item): ?>
	     <tr>
	     <th><?php echo $order_item['nama_tahun']; ?></th>
	     <th><?php echo $order_item['St']; ?></th>
	     <th><?php echo round($order_item['St2'], 2); ?></th>
	     <th><?php echo round($order_item['St3'],2); ?></th>
	     <th><?php echo round($at = $order_item['At'], 2); ?></th>
	     <th><?php echo round($bt = $order_item['Bt'], 2); ?></th>
	     <th><?php echo round($order_item['ft+m'], 2); ?></th>
		 <th><?php echo round($order_item['MAPE'], 1); ?>%</th>
	     <th><?php echo round($order_item['datareal'], 0); ?></th>
	    </tr>	
	</div>

	<!-- =</table>
</div> -->

<?php endforeach; ?>
</table>


		<br>
		<br>
		<h3>Anda harus menyediakan stok blangko di bulan <b><?php
	 			if($nama_bulan == 1)
	 			{
	 				echo "Januari";
	 			}
	 			elseif($nama_bulan == 2)
	 			{
	 				echo "Februari";
	 			}
	 			elseif($nama_bulan == 3) 
	 			{
	 				echo "Maret";
	 			}
	 			elseif($nama_bulan == 4)
	 			{
	 				echo "April";
	 			}
	 			elseif($nama_bulan == 5) 
	 			{
	 				echo "Mei";
	 			}
	 			elseif($nama_bulan == 6)
	 			{
	 				echo "Juni";
	 			}
	 			elseif($nama_bulan == 7)
	 			{
	 				echo "Juli";
	 			}
	 			elseif($nama_bulan == 8)
	 			{
	 				echo "Agustus";
	 			}
	 			elseif($nama_bulan == 9)
	 			{
	 				echo "September";
	 			}
	 			elseif($nama_bulan == 10)
	 			{
	 				echo "Oktober";
	 			}elseif($nama_bulan == 11)
	 			{
	 				echo "November";
	 			}else{
	 				echo "Desember";
	 			}
	 			 ?></b> Tahun <b><?php echo $nama_tahun;?></b> sebesar : <b><?php echo $hasilperamalanview; ?></b></h3>
		
		<br>
		<br>
		<br>
		<h2>Perbandingan</h2>

		<table class="table table-striped table-bordered">
		<tr>
			<th><center>Data Permintaan</center></th>
			<th><center>Peramalan</center></th>
			<th><center>Tingkat Error / MAPE</center></th>
	    </tr>
	     <?php foreach ($order as $order_item): ?>
	    <tr>
	    	<th><center><?php echo $order_item['St']; ?></center></th>
	    	<th><center><?php echo $order_item['ft+m']; ?></center></th>
	    	<th><center><?php echo round($order_item['MAPE'], 1); ?>%</center></th>
	    </tr>
	    <?php endforeach; ?>

</table>
<br><br>
<center><div id="chartContainer" style="height: 350px; width: 80%;"></div></center>
<script src="<?php echo base_url(); ?>assets/canvasjs.min.js"></script>

<?php $this->load->view('footer') ?>