<?php $this->load->view('header_dashuser'); ?>
    <form class="form-horizontal" action="<?php echo base_url().'index.php/tahun/tambah_tahun'; ?>" method="post" enctype="multipart/form-data">
         <h2><center><span class="table-project-n">Tambah</span> Data Tahun</center></h1>
            <br>
            <br>
        <div class="form-group">
            <label class="col-lg-2 control-label">ID</label>
                <div class="col-lg-5">
                    <input type="text" name="id_tahun">
                </div>
        </div>
        <div class="form-group">
            <label class="col-lg-2 control-label">Tahun</label>
                <div class="col-lg-5">
                    <input type="text" name="nama_tahun">
                </div>
        </div>
        <div class="form-group">
            <div class="col-lg-5">
                <label class="col-lg-2 control-label"></label>
                <tr>
                    <input type="submit" value="Tambah" class="btn btn-primary" class="glyphicon glyphicon-plus">
                </tr>
            </div>
        </div>
        </table>
    </form> 
<?php $this->load->view('footer'); ?>