<?php $this->load->view('header_user'); ?>
	<form class="form-horizontal" action="<?php echo base_url().'index.php/ektp/tambah_blangko'; ?>" method="post" enctype="multipart/form-data">
        <h2><center><span class="table-project-n">Tambah</span> Data Permintaan</center></h1>
            <br>
            <br>
		<div class="form-group">
    		<label class="col-lg-2 control-label">ID</label>
    			<div class="col-lg-5">
    				<input type="text" name="id">
    			</div>
		</div>
		<div class="form-group">
    		<label class="col-lg-2 control-label">Bulan</label>
    			<div class="col-lg-2">
    				<select class="form-control" name="id_bulan" id="id_bulan">
                            <?php foreach($groups as $row)
                                { 
                                  echo '<option value="'.$row->id_bulan.'">'.$row->nama_bulan.'</option>';
                                }
                                ?>
    				</select>
    			</div>
		</div>
		<div class="form-group">
    		<label class="col-lg-2 control-label">Tahun</label>
    			<div class="col-lg-2">
    				<select class="form-control" name="id_tahun" id="id_tahun">
                            <?php foreach($groups1 as $row)
                                { 
                                  echo '<option value="'.$row->id_tahun.'">'.$row->nama_tahun.'</option>';
                                }
                                ?>
                                <!-- <option value=""><a href="v_inputtahun.php">Tambah Tahun</a></option> -->
                    </select>
    			</div>
		</div>
		
		<div class="form-group">
    		<label class="col-lg-2 control-label">Blangko Terpakai</label>
    			<div class="col-lg-5">
    				<input type="text" name="terpakai">
    			</div>
		</div>
		<div class="form-group">
			<label class="col-lg-2 control-label"></label>
				<div class="col-lg-5">
                <tr>
		   			<input type="submit" value="Tambah" class="btn btn-primary" class="glyphicon glyphicon-plus">
				</tr>
                <a href="<?php echo site_url('Ektp/ektp');?>" class="btn btn-default">Kembali</a>
			</div>
		</div>
		</table>
	</form>	
<?php $this->load->view('footer'); ?>