<?php $this->load->view('header_user'); ?>
	<form class="form-horizontal" action="<?php echo base_url().'index.php/permintaan/tambah_permintaan'; ?>" method="post" enctype="multipart/form-data">
		<div class="form-group">
    		<label class="col-lg-2 control-label">ID</label>
    			<div class="col-lg-5">
    				<input type="text" name="id_permintaan">
    			</div>
		</div>
		<div class="form-group">
    		<label class="col-lg-2 control-label">Bulan</label>
    			<div class="col-lg-5">
    				<select class="form-control" name="id_bulan" id="id_bulan">
                            <?php foreach($groups as $row)
                                { 
                                  echo '<option value="'.$row->id_bulan.'">'.$row->nama_bulan.'</option>';
                                }
                                ?>
    				</select>
    			</div>
		</div>
		<div class="form-group">
    		<label class="col-lg-2 control-label">Tahun</label>
    			<div class="col-lg-5">
    				<select class="form-control" name="id_tahun" id="id_tahun">
                            <?php foreach($groups1 as $row)
                                { 
                                  echo '<option value="'.$row->id_tahun.'">'.$row->nama_tahun.'</option>';
                                }
                                ?>
                    </select>
    			</div>
		</div>
		
		<div class="form-group">
    		<label class="col-lg-2 control-label">Permintaan</label>
    			<div class="col-lg-5">
    				<input type="text" name="jml_permintaan">
    			</div>
		</div>
		<div class="form-group">
			<div class="col-lg-5">
				<label class="col-lg-2 control-label"></label>
				<tr>
		   			<input type="submit" value="Tambah" class="btn btn-primary" class="glyphicon glyphicon-plus">
				</tr>
			</div>
		</div>
		</table>
	</form>	
<?php $this->load->view('footer'); ?>