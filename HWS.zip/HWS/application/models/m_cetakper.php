<?php 
 
class M_cetakper extends CI_Model{
	function tampil_data(){
		$query = $this->db->query("SELECT * FROM forecasting");
		return $query->result();
	}
	function tampil_data_perbulan($bulan){
		$query = $this->db->query("SELECT blangko.id, bulan.nama_bulan as nama_bulan, tahun.nama_tahun, blangko.terpakai FROM blangko JOIN bulan on bulan.id_bulan=blangko.id_bulan join tahun on tahun.id_tahun=blangko.id_tahun where blangko.id_bulan = $bulan");
		return $query->result();
	}
	function input_data($data,$table){
		$this->db->insert($table,$data);
	}

	function get_bulan(){
		return $this->db->get('bulan');
	}

	function get_tahun(){
		return $this->db->get('tahun');
	}

	function getAllGroups()
        {

            $query = $this->db->query('SELECT * FROM bulan');
            return $query->result();

        }
    function getAllTahun()
        {

            $query = $this->db->query('SELECT * FROM tahun');
            return $query->result();

        }
 
}