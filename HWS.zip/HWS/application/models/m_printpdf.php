<?php
class m_printpdf extends CI_Model
{
 function fetch()
 {
  $this->db->order_by('id', 'DESC');
  return $this->db->get('blangko');
 }
 function fetch_single_details($id)
 {
  $this->db->where('id', $id);
  $data = $this->db->get('blangko');
  $output = '<table width="100%" cellspacing="5" cellpadding="5">';
  foreach($data->result() as $row)
  {
   $output .= '
   <tr>
    <td width="100%">
     <p><b>ID : </b>'.$row->id.'</p>
     <p><b>Bulan Ke : </b>'.$row->id_bulan.'</p>
     <p><b>Tahun : </b>'.$row->id_tahun.'</p>
     <p><b>Blangko Terpakai : </b>'.$row->terpakai.'</p>
    </td>
   </tr>
   ';
  }
  $output .= '
  <tr>
   <td colspan="2" align="center"><a href="'.base_url().'v_printpdf" class="btn btn-primary">Back</a></td>
  </tr>
  ';
  $output .= '</table>';
  return $output;
 }
}

?>