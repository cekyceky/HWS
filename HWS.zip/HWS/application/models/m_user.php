<?php 
 
class M_user extends CI_Model{
	function tampil_data(){
		$query = $this->db->query("SELECT blangko.id, bulan.nama_bulan as nama_bulan, tahun.nama_tahun, blangko.terpakai FROM blangko JOIN bulan on bulan.id_bulan=blangko.id_bulan join tahun on tahun.id_tahun=blangko.id_tahun");
		return $query->result();
	}
 
	function input_data($data,$table){
		$this->db->insert($table,$data);
	}

	function get_bulan(){
		return $this->db->get('bulan');
	}

	function get_tahun(){
		return $this->db->get('tahun');
	}

	function edit_data($where,$table){		
		return $this->db->get_where($table,$where);
	}
 
	function update_data($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}
	
	function hapus_data($where,$table){
		$this->db->where($where);
		$this->db->delete($table);
	}
 
}