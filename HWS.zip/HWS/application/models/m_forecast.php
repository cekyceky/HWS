<?php

class M_forecast extends CI_Model{

	public function getMatriksA()
	{
		$query=$this->db->query("select * from blangko");
		return $query->result();
	}

	public function getMatriksB()
	{
		$query=$this->db->query("select * from permintaan");
		return $query->result();
	}	
	
	function getdata()
	{
		$data = $this->db->query('select jumlah, parameter from data1 join data2 on data1.id_data = data2.id');
		return $data->result();
	}

	function getdata2(){
		$data = $this->db->get('data2');
		return $data->result();
	}

	public function getPerBulan($bulan)
	{
		// $query2 = $this->db->query("SELECT blangko.id, bulan.nama_bulan as nama_bulan, tahun.nama_tahun, blangko.terpakai FROM blangko JOIN bulan on bulan.id_bulan=blangko.id_bulan join tahun on tahun.id_tahun=blangko.id_tahun");
		$query=$this->db->query("SELECT * FROM blangko join bulan on blangko.id_bulan = bulan.id_bulan JOIN tahun on blangko.id_tahun = tahun.id_tahun WHERE blangko.id_bulan = '$bulan'");
		return $query->result();
	}

	public function getTahunAkhir()
	{
		$query=$this->db->query("SELECT max(tahun.nama_tahun) as tahun FROM blangko JOIN tahun on blangko.id_tahun = tahun.id_tahun");
		return $query->result();
	}

	public function insertkan($bulan,$tahun,$hasilperamalan)
	{
		$data = array (
			'bulan' => $bulan,
			'tahun' => $tahun,
			'hasil' => $hasilperamalan
		);
		$this->db->insert('forecasting',$data);
	}

	public function cekduplikasi($bulan,$tahun)
	{
		$query=$this->db->query("SELECT * from forecasting where bulan = '$bulan' and tahun = '$tahun'");
		return $query->num_rows();
	}

	public function updatedata($bulan,$tahun,$hasilperamalan)
	{
		$data = array (
			'bulan' => $bulan,
			'tahun' => $tahun,
			'hasil' => $hasilperamalan
		);
		$this->db->where('bulan', $bulan);
		$this->db->where('tahun', $tahun);
		$this->db->update('forecasting',$data);
	}
}