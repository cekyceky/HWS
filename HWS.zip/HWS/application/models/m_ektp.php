<?php 
 
class M_ektp extends CI_Model{
	function tampil_data(){
		// $query = $this->db->query("SELECT blangko.id, bulan.nama_bulan as nama_bulan, tahun.nama_tahun, blangko.terpakai FROM blangko JOIN bulan on bulan.id_bulan=blangko.id_bulan join tahun on tahun.id_tahun=blangko.id_tahun");
		// return $query->result();
		$query = $this->db->query("SELECT blangko.id, bulan.nama_bulan as nama_bulan, tahun.nama_tahun, blangko.terpakai, cetak.jml_cetak, blangko.terpakai-cetak.jml_cetak as hasilpengurangan FROM blangko JOIN bulan on bulan.id_bulan=blangko.id_bulan join tahun on tahun.id_tahun=blangko.id_tahun JOIN cetak ON cetak.id_cetak=blangko.id");
		return $query->result();
	}
	function tampil_data_perbulan($bulan){
		// $query = $this->db->query("SELECT blangko.id, bulan.nama_bulan as nama_bulan, tahun.nama_tahun, blangko.terpakai FROM blangko JOIN bulan on bulan.id_bulan=blangko.id_bulan join tahun on tahun.id_tahun=blangko.id_tahun where blangko.id_bulan = $bulan");
		// return $query->result();
		$query = $this->db->query("SELECT blangko.id, bulan.nama_bulan as nama_bulan, tahun.nama_tahun, blangko.terpakai, cetak.jml_cetak, blangko.terpakai-cetak.jml_cetak as hasilpengurangan FROM blangko JOIN bulan on bulan.id_bulan=blangko.id_bulan join tahun on tahun.id_tahun=blangko.id_tahun JOIN cetak ON cetak.id_cetak=blangko.id where blangko.id_bulan = $bulan");
		return $query->result();
	}
	function tampil_data_pertahun($tahun){
		// $query = $this->db->query("SELECT blangko.id, bulan.nama_bulan as nama_bulan, tahun.nama_tahun, blangko.terpakai FROM blangko JOIN bulan on bulan.id_bulan=blangko.id_bulan join tahun on tahun.id_tahun=blangko.id_tahun where blangko.id_tahun = $tahun");
		// return $query->result();
		$query = $this->db->query("SELECT blangko.id, bulan.nama_bulan as nama_bulan, tahun.nama_tahun, blangko.terpakai, cetak.jml_cetak, blangko.terpakai-cetak.jml_cetak as hasilpengurangan FROM blangko JOIN bulan on bulan.id_bulan=blangko.id_bulan join tahun on tahun.id_tahun=blangko.id_tahun JOIN cetak ON cetak.id_cetak=blangko.id where blangko.id_tahun = $tahun");
		return $query->result();
	}
	function tampil_pengurangan(){
		$query = $this->db->query("SELECT blangko.id, bulan.nama_bulan as nama_bulan, tahun.nama_tahun, blangko.terpakai, cetak.jml_cetak, blangko.terpakai-cetak.jml_cetak as hasilpengurangan FROM blangko JOIN bulan on bulan.id_bulan=blangko.id_bulan join tahun on tahun.id_tahun=blangko.id_tahun JOIN cetak ON cetak.id_cetak=blangko.id");
		return $query->result();
	}

	function input_data($data,$table){
		$this->db->insert($table,$data);
	}

	function get_bulan(){
		return $this->db->get('bulan');
	}

	function get_tahun(){
		return $this->db->get('tahun');
	}
	function tampil_admin(){
		$query = $this->db->query("SELECT blangko.id, bulan.nama_bulan as nama_bulan, tahun.nama_tahun, blangko.terpakai, cetak.jml_cetak, blangko.terpakai-cetak.jml_cetak as hasilpengurangan FROM blangko JOIN bulan on bulan.id_bulan=blangko.id_bulan join tahun on tahun.id_tahun=blangko.id_tahun JOIN cetak ON cetak.id_cetak=blangko.id");
		return $query->result();
	}

	public function getBlangkoWhereLike($field, $search)
	{
	    $query = $this->db->like($field, $search)->orderBy('registered_at')->get('blangko');
	    return $query->result();
	}

	public function get_list_months()
    {
        $this->db->select('id_bulan');
        $this->db->from($this->table);
        $this->db->order_by('bulan','asc');
        $query = $this->db->get();
        $result = $query->result();
 
        $months = array();
        foreach ($result as $row) 
        {
            $months[] = $row->bulan;
        }
        return $months;
    }

	function edit_data($where,$table){		
		return $this->db->get_where($table,$where);
	}
 
	function update_data($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}
	
	function hapus_data($where,$table){
		$this->db->where($where);
		$this->db->delete($table);
	}

	function getAllGroups()
        {

            $query = $this->db->query('SELECT * FROM bulan');
            return $query->result();

        }
    function getAllTahun()
        {

            $query = $this->db->query('SELECT * FROM tahun');
            return $query->result();

        }
 
}