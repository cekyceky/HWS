<?php 
 
class M_report extends CI_Model{
	function tampil_data(){
		$query = $this->db->query("SELECT blangko.id, bulan.nama_bulan as nama_bulan, tahun.nama_tahun, blangko.terpakai, cetak.jml_cetak, blangko.terpakai-cetak.jml_cetak as hasilpengurangan FROM blangko JOIN bulan on bulan.id_bulan=blangko.id_bulan join tahun on tahun.id_tahun=blangko.id_tahun JOIN cetak ON cetak.id_cetak=blangko.id");
		return $query->result();
	}
 
	function input_data($data,$table){
		$this->db->insert($table,$data);
	}

	function get_bulan(){
		return $this->db->get('bulan');
	}

	function get_tahun(){
		return $this->db->get('tahun');
	}

	function edit_data($where,$table){		
		return $this->db->get_where($table,$where);
	}
 
	function update_data($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}
	
	function hapus_data($where,$table){
		$this->db->where($where);
		$this->db->delete($table);
	}
	
	function getAllBulan()
        {

            $query = $this->db->query('SELECT * FROM bulan');
            return $query->result();

        }
    function getAllTahun()
        {

            $query = $this->db->query('SELECT * FROM tahun');
            return $query->result();

        }
    public function insertkan($bulan,$tahun,$hasilpengurangan)
	{
		$data = array (
			'bulan' => $bulan,
			'tahun' => $tahun,
			'hasilpengurangan' => $hasilpengurangan
		);
		$this->db->insert('report',$data);
	}

	public function cekduplikasi($bulan,$tahun)
	{
		$query=$this->db->query("SELECT * from report where bulan = '$bulan' and tahun = '$tahun'");
		return $query->num_rows();
	}

	public function updatedata($bulan,$tahun,$hasilpengurangan)
	{
		$data = array (
			'bulan' => $bulan,
			'tahun' => $tahun,
			'hasilpengurangan' => $hasilpengurangan
		);
		$this->db->where('bulan', $bulan);
		$this->db->where('tahun', $tahun);
		$this->db->update('report',$data);
	}
 
}