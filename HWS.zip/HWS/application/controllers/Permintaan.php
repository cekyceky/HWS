<?php 
 
class Permintaan extends CI_Controller{
 
	function __construct(){
		parent::__construct();		
		$this->load->model('m_permintaan');
		$this->load->helper('url');

		if ($this->session->userdata('level') != TRUE) {
			# code...
			redirect('');
		}

	}
 
	function index(){
		$data['permintaan'] = $this->m_permintaan->tampil_data();
		$this->load->view('v_tampilpermintaan',$data);
	}
 
	function tambah(){
		$this->load->model('m_permintaan');
		// $data['bulan']=$this->m_user->result();
		// $data['tahun']=$this->m_user->result();
		//$this->load->view('v_inputktp');
		$data['groups'] = $this->m_permintaan->getAllBulan();
        $data['groups1'] = $this->m_permintaan->getAllTahun();
        $this->load->view('v_inputpermintaan',$data);
	}

	function tambah_permintaan(){

		// $this->form_validation->set_rules('id', 'id', 'trim|required');
		// $this->form_validation->set_rules('nama_user', 'nama_user', 'trim|required');
		// $this->form_validation->set_rules('id_bulan', 'id_bulan', 'trim|required');
		// $this->form_validation->set_rules('id_tahun', 'id_tahun', 'trim|required');
		// $this->form_validation->set_rules('id_prodi', 'id_prodi', 'trim|required');
		// $this->form_validation->set_rules('terpakai', 'terpakai', 'trim|required');

		$id_permintaan = $this->input->post('id_permintaan');
		$id_bulan = $this->input->post('id_bulan');
		$id_tahun = $this->input->post('id_tahun');
 		$jml_permintaan = $this->input->post('jml_permintaan');

		$data = array(
			'id_permintaan' => $id_permintaan,
			'id_bulan' => $id_bulan,
			'id_tahun' => $id_tahun,
			'jml_permintaan' => $jml_permintaan
			);
		$this->m_permintaan->input_data($data,'permintaan');
		redirect('permintaan/index');

	}
 
	function edit($id_permintaan){
		$where = array('id_permintaan' => $id_permintaan);
		$data['permintaan'] = $this->m_permintaan->edit_data($where,'permintaan')->result();
		$data['groups'] = $this->m_permintaan->getAllBulan();
        $data['groups1'] = $this->m_permintaan->getAllTahun();
		$this->load->view('v_editpermintaan',$data);
	}

	function update(){
	$id_permintaan = $this->input->post('id_permintaan');
	$id_bulan = $this->input->post('id_bulan');
	$id_tahun = $this->input->post('id_tahun');
	$jml_permintaan = $this->input->post('jml_permintaan');

	$data = array(
		'id_permintaan' => $id_permintaan,
		'id_bulan' => $id_bulan,
		'id_tahun' => $id_tahun,
		'jml_permintaan' => $jml_permintaan
		);
 
		$where = array(
			'id_permintaan' => $id_permintaan
		);
 
		$this->m_permintaan->update_data($where,$data,'permintaan');
		redirect('permintaan/index');
	}

	function hapus($id_permintaan){
		$where = array('id_permintaan' => $id_permintaan);
		$this->m_permintaan->hapus_data($where,'permintaan');
		redirect('permintaan/index');
	}


 
}