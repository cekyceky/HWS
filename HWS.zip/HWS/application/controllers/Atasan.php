<?php 
 
class Atasan extends CI_Controller{
 
	function __construct(){
		parent::__construct();		
		$this->load->model('m_admin');
		$this->load->helper('url');

		if ($this->session->userdata('role') != TRUE) {
			# code...
			redirect('');
		}

	}
 
	function index(){
		// $data['users'] = $this->m_admin->tampil_data()->result();
		// $this->load->view('v_tampiluser',$data);
		$this->load->view('dashboard_atasan');
	}
	// function user(){
	// 	$data['users'] = $this->m_admin->tampil_data()->result();
	// 	$this->load->view('v_tampiluser',$data);
	// }
 
	// function tambah(){
	// 	$this->load->model('m_admin');
	// 	$this->load->view('v_inputuser');
	// }

	// function tambah_user(){

	// 	// $this->form_validation->set_rules('nip', 'nip', 'trim|required');
	// 	// $this->form_validation->set_rules('nama_user', 'nama_user', 'trim|required');
	// 	// $this->form_validation->set_rules('username', 'username', 'trim|required');
	// 	// $this->form_validation->set_rules('password', 'password', 'trim|required');
	// 	// $this->form_validation->set_rules('id_prodi', 'id_prodi', 'trim|required');
	// 	// $this->form_validation->set_rules('level', 'level', 'trim|required');

	// 	$nip = $this->input->post('nip');
	// 	$nama = $this->input->post('nama');
	// 	$username = $this->input->post('username');
	// 	$password = MD5($this->input->post('password'));
 // 		$level = $this->input->post('level');

	// 	$data = array(
	// 		'nip' => $nip,
	// 		'nama' => $nama,
	// 		'username' => $username,
	// 		'password' => $password,
	// 		'level' => $level
	// 		);
	// 	$this->m_admin->input_data($data,'users');
	// 	redirect('admin/index');
	// }
 
	// function edit($nip){
	// 	$where = array('nip' => $nip);
	// 	$data['users'] = $this->m_admin->edit_data($where,'users')->result();
	// 	$this->load->view('v_edituser',$data);
	// }

	// function update(){
	// $nip = $this->input->post('nip');
	// $nama = $this->input->post('nama');
	// $username = $this->input->post('username');
	// $password = $this->input->post('password');
	// $level = $this->input->post('level');

	// $data = array(
	// 	'nip' => $nip,
	// 	'nama' => $nama,
	// 	'username' => $username,
	// 	'password' => $password,
	// 	'level' => $level
	// 	);
 
	// 	$where = array(
	// 		'nip' => $nip
	// 	);
 
	// 	$this->m_admin->update_data($where,$data,'users');
	// 	redirect('admin/index');
	// }

	// function hapus($nip){
	// 	$where = array('nip' => $nip);
	// 	$this->m_admin->hapus_data($where,'users');
	// 	redirect('admin/index');
	// }
 
}