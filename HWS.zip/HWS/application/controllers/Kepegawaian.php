<?php 
 
class Kepegawaian extends CI_Controller{
 
	function __construct(){
		parent::__construct();		
		$this->load->model('m_ektp');
		$this->load->helper('url');

		if ($this->session->userdata('role') != TRUE) {
			# code...
			redirect('');
		}

	}
 
	function index(){
		
		// $data['blangko'] = $this->m_ektp->tampil_data();
		// $this->load->view('v_tampilktp',$data);
		$this->load->view('dashboard_user');
	}
	// function ektp(){
	// 	$data['blangko'] = $this->m_ektp->tampil_pengurangan();
	// 	$this->load->view('v_admintampilktp',$data);
	// }

	// function ktp(){
		
	// 	$data['blangko'] = $this->m_ektp->tampil_data();
	// 	$this->load->view('v_tampilktp',$data);
	// }

	// function tampil_per_bulan()
	// {
	
	// 	$bulan = $this->input->post('bulan');
	// 	$data['blangko'] = $this->m_ektp->tampil_data_perbulan($bulan);
	// 	$this->load->view('v_tampilktp',$data);
	// }

	// function tampil_per_tahun()
	// {
	
	// 	$tahun = $this->input->post('tahun');
	// 	$data['blangko'] = $this->m_ektp->tampil_data_pertahun($tahun);
	// 	$this->load->view('v_tampilktp',$data);
	// }

	// function admin(){
	// 	$this->load->model('m_ektp');
	// 	$data['blangko'] = $this->m_ektp->tampil_admin();
	// 	$this->load->view('v_admintampilktp', $data);

	// }

	// function tampil_admin_perbulan()
	// {
	
	// 	$bulan = $this->input->post('bulan');
	// 	$data['blangko'] = $this->m_ektp->tampil_data_perbulan($bulan);
	// 	$this->load->view('v_admintampilktp',$data);
	// }

 
	// function tambah(){
	// 	$this->load->model('m_ektp');
	// 	// $data['bulan']=$this->m_user->result();
	// 	// $data['tahun']=$this->m_user->result();
	// 	//$this->load->view('v_inputktp');
	// 	$data['groups'] = $this->m_ektp->getAllGroups();
 //        $data['groups1'] = $this->m_ektp->getAllTahun();
 //        $this->load->view('v_inputktp',$data);
	// }

	// function tambah_blangko(){

	// 	// $this->form_validation->set_rules('id', 'id', 'trim|required');
	// 	// $this->form_validation->set_rules('nama_user', 'nama_user', 'trim|required');
	// 	// $this->form_validation->set_rules('id_bulan', 'id_bulan', 'trim|required');
	// 	// $this->form_validation->set_rules('id_tahun', 'id_tahun', 'trim|required');
	// 	// $this->form_validation->set_rules('id_prodi', 'id_prodi', 'trim|required');
	// 	// $this->form_validation->set_rules('terpakai', 'terpakai', 'trim|required');

	// 	$id = $this->input->post('id');
	// 	$id_bulan = $this->input->post('id_bulan');
	// 	$id_tahun = $this->input->post('id_tahun');
 // 		$terpakai = $this->input->post('terpakai');

	// 	$data = array(
	// 		'id' => $id,
	// 		'id_bulan' => $id_bulan,
	// 		'id_tahun' => $id_tahun,
	// 		'terpakai' => $terpakai
	// 		);
	// 	$this->m_ektp->input_data($data,'blangko');
	// 	redirect('ektp');

	// }
 
	// function edit($id){
	// 	$where = array('id' => $id);
	// 	$data['blangko'] = $this->m_ektp->edit_data($where,'blangko')->result();
	// 	$data['groups'] = $this->m_ektp->getAllGroups();
 //        $data['groups1'] = $this->m_ektp->getAllTahun();
	// 	$this->load->view('v_editktp',$data);
	// }

	// function update(){
	// $id = $this->input->post('id');
	// $id_bulan = $this->input->post('id_bulan');
	// $id_tahun = $this->input->post('id_tahun');
	// $terpakai = $this->input->post('terpakai');

	// $data = array(
	// 	'id' => $id,
	// 	'id_bulan' => $id_bulan,
	// 	'id_tahun' => $id_tahun,
	// 	'terpakai' => $terpakai
	// 	);
 
	// 	$where = array(
	// 		'id' => $id
	// 	);
 
	// 	$this->m_ektp->update_data($where,$data,'blangko');
	// 	redirect('ektp');
	// }

	// function hapus($id){
	// 	$where = array('id' => $id);
	// 	$this->m_ektp->hapus_data($where,'blangko');
	// 	redirect('ektp');
	// }

	// public function print()
	// {
	// 	$this->load->model('m_ektp');
	// 	$data['blangko'] = $this->m_ektp->tampil_pengurangan();
	// 	$this->load->view('report', $data);

	// }


 
}