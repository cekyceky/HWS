<?php 
 
class User extends CI_Controller{
 
	function __construct(){
		parent::__construct();		
		$this->load->model('m_user');
		$this->load->helper('url');

		if ($this->session->userdata('level') != TRUE) {
			# code...
			redirect('');
		}

	}
 
	function index(){
		$data['blangko'] = $this->m_user->tampil_data();
		$this->load->view('v_tampilktp',$data);
	}
 
	function tambah(){
		$this->load->model('m_user');
		// $data['bulan']=$this->m_user->result();
		// $data['tahun']=$this->m_user->result();
		$this->load->view('v_inputktp');
	}

	function tambah_blangko(){

		// $this->form_validation->set_rules('id', 'id', 'trim|required');
		// $this->form_validation->set_rules('nama_user', 'nama_user', 'trim|required');
		// $this->form_validation->set_rules('id_bulan', 'id_bulan', 'trim|required');
		// $this->form_validation->set_rules('id_tahun', 'id_tahun', 'trim|required');
		// $this->form_validation->set_rules('id_prodi', 'id_prodi', 'trim|required');
		// $this->form_validation->set_rules('terpakai', 'terpakai', 'trim|required');

		$id = $this->input->post('id');
		$id_bulan = $this->input->post('id_bulan');
		$id_tahun = $this->input->post('id_tahun');
 		$terpakai = $this->input->post('terpakai');

		$data = array(
			'id' => $id,
			'id_bulan' => $id_bulan,
			'id_tahun' => $id_tahun,
			'terpakai' => $terpakai
			);
		$this->m_user->input_data($data,'blangko');
		redirect('user/index');
	}
 
	function edit($id){
		$where = array('id' => $id);
		$data['blangko'] = $this->m_user->edit_data($where,'blangko')->result();
		$this->load->view('v_editktp',$data);
	}

	function update(){
	$id = $this->input->post('id');
	$id_bulan = $this->input->post('id_bulan');
	$id_tahun = $this->input->post('id_tahun');
	$terpakai = $this->input->post('terpakai');

	$data = array(
		'id' => $id,
		'id_bulan' => $id_bulan,
		'id_tahun' => $id_tahun,
		'terpakai' => $terpakai
		);
 
		$where = array(
			'id' => $id
		);
 
		$this->m_user->update_data($where,$data,'blangko');
		redirect('user/index');
	}

	function hapus($id){
		$where = array('id' => $id);
		$this->m_user->hapus_data($where,'blangko');
		redirect('user/index');
	}
 
}