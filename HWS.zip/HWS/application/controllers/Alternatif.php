<?php
class Alternatif extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('Mdl_Alternatif');
	}
}