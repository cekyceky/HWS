<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Login extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('m_login');
	}
	public function index(){
		$d['title'] = 'Sistem Seleksi Calon Karyawan';
		$d['judul'] = 'Login';
		$this->load->view('v_login', $d);
	}

	function masuk()
	{
		$username = $this->input->post('username');
		$password = $this->input->post('password');

		$cek = $this->m_login->cek($username, $password);
		if($cek->num_rows() == 1){

			foreach($cek->result() as $data)
				$sess_data['nama_lengkap'] = $data->nama_lengkap;
				$sess_data['id_pengguna'] = $data->id_pengguna;
				$sess_data['role'] = $data->role;
				$sess_data['username'] = $data->username;
				$sess_data['password'] = $data->password;
				$this->session->set_userdata($sess_data);

			if($this->session->userdata('role') == 'atasan')
			{
				redirect('Atasan');
			}
			else if($this->session->userdata('role') == 'kepegawaian')
			{
				redirect('Kepegawaian');
			}
			else if($this->session->userdata('role') == 'manajer')
			{
				redirect('manajer');
			}
		}

		else
		{
			$this->session->set_flashdata('pesan', 'Maaf, kombinasi username dengan password salah.');
			redirect('');
		}
	}

	function keluar()
	{
		$this->session->sess_destroy();
		redirect('');
	}
}