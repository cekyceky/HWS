<?php
class NilaiAwal extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('Mdl_NilaiAwal');
	}
}