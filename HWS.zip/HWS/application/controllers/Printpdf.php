<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Printpdf extends CI_Controller {

 public function __construct()
 {
  parent::__construct();
  $this->load->model('m_printpdf');
  $this->load->library('pdf');
 }

 public function index()
 {
  $data['blangko'] = $this->m_printpdf->fetch();
  // $this->load->view('v_printpdf', $data);
  if($this->uri->segment(3))
  {
   $id = $this->uri->segment(3);
   $html_content = '<h3 align="center">Convert HTML to PDF in CodeIgniter using Dompdf</h3>';
   $html_content .= $this->m_printpdf->fetch_single_details($id);
   $this->pdf->loadHtml($html_content);
   $this->pdf->render();
   $this->pdf->stream("".$id.".pdf", array("Attachment"=>0));
  }
 }

 // public function details()
 // {
 //  if($this->uri->segment(3))
 //  {
 //   $customer_id = $this->uri->segment(3);
 //   $data['customer_details'] = $this->htmltopdf_model->fetch_single_details($customer_id);
 //   $this->load->view('htmltopdf', $data);
 //  }
 // }

 public function pdfdetails()
 {
  if($this->uri->segment(3))
  {
   $id = $this->uri->segment(3);
   $html_content = '<h3 align="center">Convert HTML to PDF in CodeIgniter using Dompdf</h3>';
   $html_content .= $this->m_printpdf->fetch_single_details($id);
   $this->pdf->loadHtml($html_content);
   $this->pdf->render();
   $this->pdf->stream("".$id.".pdf", array("Attachment"=>0));
  }
 }

}

?>