<?php 
 
class ClnKaryawan extends CI_Controller{
 
	function __construct(){
		parent::__construct();		
		$this->load->model('m_tahun');
		$this->load->helper('url');

		if ($this->session->userdata('role') != TRUE) {
			# code...
			redirect('');
		}

	}
 
	function index(){
		$data['tahun'] = $this->m_tahun->tampil_data()->result();
		$this->load->view('v_tampiltahun',$data);
		
	}
 
	function input(){
		$this->load->model('m_tahun');
		$data['data_alternatif'] = $this->m_tahun->tampil_data()->result();
		$this->load->view('v_tampiltahun',$data);
	}

	function tambah_tahun(){

		$id_tahun = $this->input->post('id_tahun');
		$nama_tahun = $this->input->post('nama_tahun');

		$data = array(
			'id_tahun' => $id_tahun,
			'nama_tahun' => $nama_tahun
			);
		$this->m_tahun->input_data($data,'tahun');
		redirect('tahun');
	}
 
	function edit($id_tahun){
		$where = array('id_tahun' => $id_tahun);
		$data['tahun'] = $this->m_tahun->edit_data($where,'tahun')->result();
		$this->load->view('v_edittahun',$data);
	}

	function update(){
	$id_tahun = $this->input->post('id_tahun');
	$nama_tahun = $this->input->post('nama_tahun');

	$data = array(
		'id_tahun' => $id_tahun,
		'nama_tahun' => $nama_tahun
		);
 
		$where = array(
			'id_tahun' => $id_tahun
		);
 
		$this->m_tahun->update_data($where,$data,'tahun');
		redirect('tahun');
	}

	function hapus($id_tahun){
		$where = array('id_tahun' => $id_tahun);
		$this->m_tahun->hapus_data($where,'tahun');
		redirect('tahun');
	}
 
}