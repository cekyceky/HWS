<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Forecast extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('m_forecast');
		$this->load->helper('url');

		if ($this->session->userdata('level') != TRUE) {
			# code...
			redirect('');
		}
	}

	public function index()
	{
		
		$data['getTahunAkhir'] = $this->m_forecast->getTahunAkhir();
		$this->load->view('forecast', $data);
	}
	public function getBulan()
	{
		$this->load->helper('url','form');	
		$this->load->library('form_validation');
		$this->form_validation->set_rules('bulan', 'bulan', 'trim|required');
		$this->load->model('m_forecast');	


		if($this->form_validation->run()==FALSE)
		{
			$this->load->view('forecast');
			
		}
		else
		{
			$bulan = $this->input->post('bulan');
			$blankoPerbulan = $this->m_forecast->getPerBulan($bulan);
			$orderedItem = array(); //inisiasi array kosong
			//inisiasi urutan array
			//$j='id_bulan';
			//memulai for dari data di database
			foreach ($blankoPerbulan as $index => $key) {

				$alfa = 0.45;
				//ternary operator
				$prev_st2 = $index ? $orderedItem[$index - 1]["St2"] : $key->terpakai; //inline condition
				$st2 = ($alfa*$key->terpakai)+((1-$alfa)*$prev_st2);
				//ternary operator
				$prev_st3 = $index ? $orderedItem[$index - 1]["St3"] : $key->terpakai; //inline condition
				$peramalan = (2*$st2-$prev_st3)+(($alfa/(1-$alfa))*($st2-(($alfa*$st2)+((1-$alfa)*$prev_st3))))*0;
				$mape = abs(((($key->terpakai-$peramalan)/$key->terpakai)/1)*100/100);
				$asli = $peramalan*$mape;

				// var_dump($st);
				array_push($orderedItem, [
						'nama_tahun' => $key->nama_tahun,
						'St' => $key->terpakai,
						'St2' => $st2,
						'St3' => ($alfa*$st2)+((1-$alfa)*$prev_st3),
						'At' => $at=(2*$st2-$prev_st3),
						'Bt' => $bt=($alfa/(1-$alfa))*($st2-(($alfa*$st2)+((1-$alfa)*$prev_st3))),
						'ft+m' => $peramalan,
						'MAPE' => abs(((($key->terpakai-$peramalan)/$key->terpakai)/1)*100),
						'Press' => abs($key->terpakai/$peramalan*100/100),
						'datareal' => abs($asli-$key->terpakai)
				]);
			}
			$data['order'] = $orderedItem; //inisialisasi array utk mengambil data dari $ordereditem
			$data['nama_bulan'] = $this->input->post('bulan');
			$data['nama_tahun'] = $this->input->post('tahun');
			$tahun = $this->input->post('tahun');
			$data['getTahunAkhir'] = $this->m_forecast->getTahunAkhir();

			$tahunberikutnya =  $this->input->post('tahun')-$data['getTahunAkhir'][0]->tahun;
			$hasilperamalan = round($at+($bt*$tahunberikutnya),1);
			$data['hasilperamalanview'] = $hasilperamalan;

			$cekduplikasi = $this->m_forecast->cekduplikasi($bulan,$tahun);
			if($cekduplikasi >= 1)
			{
				$updatedata = $this->m_forecast->updatedata($bulan,$tahun,$hasilperamalan);
			}else{
				$insertkan = $this->m_forecast->insertkan($bulan,$tahun,$hasilperamalan);	
			}

			$data['grafik'] = $orderedItem;
			
			$this->load->view('coba', $data); //kirim ke view

		}
	}

	public function print()
	{
		$this->load->model('m_cetakper');
		$data['forecasting'] = $this->m_cetakper->tampil_data();
		$this->load->view('print', $data);

	}

}
//1. inisiasi St diawal
//2. ambil st didalam array sebelumnya