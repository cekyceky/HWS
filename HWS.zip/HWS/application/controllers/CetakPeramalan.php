<?php 
 
class CetakPeramalan extends CI_Controller{
 
	function __construct(){
		parent::__construct();		
		$this->load->model('m_cetakper');
		$this->load->helper('url');

		if ($this->session->userdata('level') != TRUE) {
			# code...
			redirect('');
		}

	}
 
	function index(){

		
		$data['forecasting'] = $this->m_cetakper->tampil_data();
		$this->load->view('v_tampilperamalan',$data);
	}

 
}